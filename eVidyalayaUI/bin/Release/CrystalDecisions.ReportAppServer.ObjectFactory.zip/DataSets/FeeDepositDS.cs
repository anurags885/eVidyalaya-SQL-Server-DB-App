﻿namespace SchoolUI.DataSets
{


    public partial class FeeDepositDS
    {
    }
}
namespace SchoolUI.DataSets {
    
    
    public partial class FeeDepositDS {
    }
}
