﻿namespace SchoolUI.DataSets
{
}

namespace SchoolUI.DataSets
{


    public partial class MonthlyFeeReportDS
    {
    }
}
