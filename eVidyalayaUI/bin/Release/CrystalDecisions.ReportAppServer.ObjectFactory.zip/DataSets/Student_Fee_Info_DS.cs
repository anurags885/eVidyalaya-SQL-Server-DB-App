﻿namespace SchoolUI.DataSets
{
}

namespace SchoolUI.DataSets
{


    public partial class Student_Fee_Info_DS
    {
    }
}
